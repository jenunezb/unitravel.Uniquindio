package co.edu.uniquindio.unitravel.entidades;

public class Administrador {
}
